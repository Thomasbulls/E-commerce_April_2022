export const allowedOrigins: string[] = [
    'https://www.yoursite.com',
    'http://127.0.0.1:3000',
    'http://localhost:3000',
    'http://127.0.0.1:3500',
    'http://localhost:3500',
];

